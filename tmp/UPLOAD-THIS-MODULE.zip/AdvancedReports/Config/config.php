<?php

return [
    'name' => 'AdvancedReports'
];
